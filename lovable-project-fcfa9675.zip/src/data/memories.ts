export type Memory = {
  src: string;
  caption: string;
  date: string;
};

// Swap these images, captions, and dates with your own anytime.
export const memories: Memory[] = [
  {
    src: "https://images.unsplash.com/photo-1518621736915-f3b1c41bfd00?auto=format&fit=crop&w=900&q=80",
    caption: "the day we met — i couldn't stop smiling",
    date: "Spring",
  },
  {
    src: "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?auto=format&fit=crop&w=900&q=80",
    caption: "coffee, rain, and your laugh ☕️",
    date: "April",
  },
  {
    src: "https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=900&q=80",
    caption: "our first long walk together",
    date: "May",
  },
  {
    src: "https://images.unsplash.com/photo-1502635385003-ee1e6a1a742d?auto=format&fit=crop&w=900&q=80",
    caption: "dancing in the kitchen at midnight",
    date: "June",
  },
  {
    src: "https://images.unsplash.com/photo-1503516459261-40c66117780a?auto=format&fit=crop&w=900&q=80",
    caption: "the trip where we got lost on purpose",
    date: "August",
  },
  {
    src: "https://images.unsplash.com/photo-1494774157365-9e04c6720e47?auto=format&fit=crop&w=900&q=80",
    caption: "you, the golden hour, my favorite picture",
    date: "October",
  },
  {
    src: "https://images.unsplash.com/photo-1518609878373-06d740f60d8b?auto=format&fit=crop&w=900&q=80",
    caption: "winter mornings, warm hands 🤍",
    date: "December",
  },
  {
    src: "https://images.unsplash.com/photo-1517816743773-6e0fd518b4a6?auto=format&fit=crop&w=900&q=80",
    caption: "and every day after — be my valentine?",
    date: "Today",
  },
];

// Change me!
export const PASSCODE = "bemyvalentine";

// Replace with any direct MP3/OGG URL.
export const SONG_URL =
  "https://cdn.pixabay.com/audio/2022/10/30/audio_347111d654.mp3";
export const SONG_TITLE = "our song";
